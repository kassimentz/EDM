# README #

Be My Pet - Find Your New Best Friend.
Rede social para adoção de pets.

### What is this repository for? ###

* Be My Pet é um aplicativo destinado a facilitar o acesso para doadores de pets encontrarem pessoas dispostas a adotarem, bem como ajudar pessoas que querem encontrar um novo amigo a entrar em contato com doadores.
* Em Desenvolvimento)
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact